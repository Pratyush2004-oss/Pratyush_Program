let student = [
    {"name":"Saurav","Class":"B.Tech","collage":"NPSEI"},
    {"name":"Pratyush","Class":"B.Tech","collage":"NPSEI"},
    {"name":"Kanchan","Class":"B.Tech","collage":"NPSEI"},
    {"name":"Mayank","Class":"B.Sc IT","collage":"MANAS"}
]
console.log(student[0].name)