#include<stdio.h>
#include<stdlib.h>

struct node {
	int data;
	struct node *left, *right;
};

void insert(){
	
}

int main(){
	
}
