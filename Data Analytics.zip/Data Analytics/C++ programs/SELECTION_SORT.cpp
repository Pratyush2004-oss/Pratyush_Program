//							  			SELECTION SORT
#include<stdio.h>

void SelectionSort(){
	int i,j,min_index;
	int arr[] = {45,75,94,12,31,56,11,64};
	int n = sizeof(arr)/sizeof(int);
	printf(" Array before Sorting : \n");;
	for(i=0;i<n;i++){
		printf(" %d \t",arr[i]);
	}
	
	for(i=0;i<n-1;i++){
		min_index = i;
		for(j=i+1;j<n;j++){
			if(arr[j] < arr[min_index]){
				min_index = j;
			}
		}
		//Swapping the values
		int temp = arr[min_index];
		arr[min_index] = arr[i];
		arr[i] = temp;
	}
	printf("\n \n Array after Sorting : \n ");
	for(i=0;i<n;i++){
		printf("%d \t",arr[i]);
	}
	
}

int main(){
	printf("\t \t \t Selection Sort \n \n");
	SelectionSort();
}
