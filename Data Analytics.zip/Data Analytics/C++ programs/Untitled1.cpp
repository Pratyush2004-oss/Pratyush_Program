#include<iostream>
using namespace std;

class queue{
	public:
		int value,pos;
		queue *next;
	queue(){
		value = 0;
		next = NULL;
	}
};


void insertion(){
	
}

int main(){
	
}
